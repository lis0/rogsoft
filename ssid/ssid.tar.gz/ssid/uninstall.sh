#!/bin/sh

rm -rf /koolshare/ssid
rm -rf /scripts/ssid_*.sh
rm -rf /webs/Module_ssid.asp