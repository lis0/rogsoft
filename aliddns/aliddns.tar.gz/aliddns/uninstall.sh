#!/bin/sh

sh /koolshare/scripts/aliddns_config.sh stop
rm /koolshare/scripts/uninstall_aliddns.sh
rm /koolshare/res/icon-aliddns.png
rm /koolshare/scripts/aliddns*
rm /koolshare/webs/Module_aliddns.asp