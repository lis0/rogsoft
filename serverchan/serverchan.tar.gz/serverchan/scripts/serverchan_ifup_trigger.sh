#!/bin/sh
source /koolshare/scripts/base.sh
/koolshare/serverchan/serverchan_ifup_trigger