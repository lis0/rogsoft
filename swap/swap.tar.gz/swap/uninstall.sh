#! /bin/sh
rm -rf /koolshare/scripts/swap*
rm -rf /koolshare/init.d/M99swap.sh
rm -rf /koolshare/webs/Module_swap.asp
rm -rf /koolshare/res/icon-swap.png
